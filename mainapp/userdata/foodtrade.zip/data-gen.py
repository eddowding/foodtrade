import json
from gen_extra_data2 import generate
from unique_name import unique_name

import uuid
import random
import csv


def gen_unique_sentence(no_words):
	f = open("american-english", 'r')
	words = f.read().split("\n")
	random.shuffle(words)
	return " ".join(words[0:no_words-1])

def gen_unique_address():
	random_list = range(42000)
	random.shuffle(random_list)
	num = random_list[0]
	with open('zip_code.csv', 'rb') as csvfile:
	    spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
	    cnt = 0
	    for row in spamreader:
	        data = row
	        if cnt-1 >= num:
	        	break
	        cnt += 1
	data = [data[0], data[1], data[2], ", ".join(data[3:])]
	return data #lat 1 lon -2 


def gen_auth_user(user_pk, username):
	'''Status: Completed'''
	auth_user = {"model":"auth.user", "pk": user_pk, "fields": {"username": username}} #first model- make pk, username as unique
	return auth_user



def gen_socialaccount(social_pk, user_pk, user, name):
	'''Status: Complete'''
	description = gen_unique_sentence(10)
	socialaccount_fields = {"user": user_pk, "provider":"1",
							"last_login": "2013-11-22 11:11:11",
        					"date_joined": "2013-11-22 11:11:11",
							 "uid": user, 
							 "extra_data": generate([description, name, user]).encode('utf8')
							} # make user from above, uid unique, extra_data is complex 
	socialaccount_socialaccount = {"model":"socialaccount.socialaccount","pk": social_pk, "fields": socialaccount_fields} #second model
	social_pk += 1
	return socialaccount_socialaccount

def gen_tradeconnection_userprofile(third_pk, user, new_location):
	'''Status: Need to generate location, lat and long'''

	

	sign_up_types = ["Individual", "Food Business", "Organization"]
	random.shuffle(sign_up_types)

	tradeconnection_userprofile_fields = {"useruid": user, "sign_up_as": sign_up_types[0],
	                                      "type_user":{
	                                      	"zip_code": new_location[0], "address": new_location[3],
	                                       "latitude": new_location[1], "longitude": new_location[2], }
	                                       }
	                                      #userid from above, sign_up_as is string = Individual, or Food Business or Organization,
	                                      # zip ode random, lat and lon from zip code.

	tradeconnection_userprofile = {"model":"tradeconnection.userprofile","pk": third_pk, "fields": tradeconnection_userprofile_fields} #third model
	third_pk += 1
	return tradeconnection_userprofile


def gen_fourth_pk(fourth_pk, user, name, new_location):
	'''Status: Need to Generate and location,'''
	description = gen_unique_sentence(10)
	status = gen_unique_sentence(15)
	tradeconnection_tweets_fields_user = {"username":user, "place":"78 Example Street, Test Town",
										  "profile_img":"https://pbs.twimg.com/profile_images/378800000141996074/6a363e3c4f2a84a956c3cb27c50b2ca0_normal.png",
										  "name":name,  "Description":description}

	tradeconnection_tweets_fields_location = {"type" : "Point", "coordinates" : [new_location[1], new_location[2]] } #copy coordinated from above lat-lon of user.

	tradeconnection_tweets_fields = {"status":status,  "parent_tweet_id":0,  "deleted":0, 
									 "tweet_id":int(uuid.uuid1()), "user": tradeconnection_tweets_fields_user, "time_stamp":1388817588,
									  "location": tradeconnection_tweets_fields_location }
									 #status any status, tweet_id is unique name, user is complex with user, name, description unique

	tradeconnection_tweets = {"model":"tradeconnection.tweets", "pk": fourth_pk, "fields": tradeconnection_tweets_fields} #fourth model
	return tradeconnection_tweets

def main(total_data, tweets_per_user):
	user_pk = 2
	social_pk = 1
	third_pk = 1
	fourth_pk = 1

	my_entry = []
	for i in range(total_data-1):
		username = unique_name[user_pk-2].replace(" ", "")
		name = unique_name[user_pk - 2]

		auth_user = gen_auth_user(user_pk, username)
		user_pk += 1

		socialaccount_socialaccount = gen_socialaccount(social_pk, user_pk-1, username, name)
		social_pk += 1

		new_location = gen_unique_address()
		tradeconnection_userprofile = gen_tradeconnection_userprofile(third_pk, username, new_location)
		third_pk += 1
		
		my_range = range(tweets_per_user[0], tweets_per_user[1])
		random.shuffle(my_range)
		entry = [auth_user, socialaccount_socialaccount, tradeconnection_userprofile]
		for i in my_range:
			tradeconnection_tweets = gen_fourth_pk(fourth_pk, username, name, new_location)
			fourth_pk += 1
			entry.append(tradeconnection_tweets)
		my_entry.extend(entry)
	with open('my_json.json', 'w') as fp:
	     json.dump(my_entry, fp)
main(10, [1, 10]  ) # first fields is the total no of users and second is tweets_per_user with [min, max]
